// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XHLS_QUICKSORT_H
#define XHLS_QUICKSORT_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xhls_quicksort_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_bus_BaseAddress;
} XHls_quicksort_Config;
#endif

typedef struct {
    u64 Control_bus_BaseAddress;
    u32 IsReady;
} XHls_quicksort;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XHls_quicksort_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XHls_quicksort_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XHls_quicksort_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XHls_quicksort_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XHls_quicksort_Initialize(XHls_quicksort *InstancePtr, u16 DeviceId);
XHls_quicksort_Config* XHls_quicksort_LookupConfig(u16 DeviceId);
int XHls_quicksort_CfgInitialize(XHls_quicksort *InstancePtr, XHls_quicksort_Config *ConfigPtr);
#else
int XHls_quicksort_Initialize(XHls_quicksort *InstancePtr, const char* InstanceName);
int XHls_quicksort_Release(XHls_quicksort *InstancePtr);
#endif

void XHls_quicksort_Start(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_IsDone(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_IsIdle(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_IsReady(XHls_quicksort *InstancePtr);
void XHls_quicksort_EnableAutoRestart(XHls_quicksort *InstancePtr);
void XHls_quicksort_DisableAutoRestart(XHls_quicksort *InstancePtr);

void XHls_quicksort_Set_arr_0_i(XHls_quicksort *InstancePtr, u32 Data);
u32 XHls_quicksort_Get_arr_0_i(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_0_o(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_0_o_vld(XHls_quicksort *InstancePtr);
void XHls_quicksort_Set_arr_1_i(XHls_quicksort *InstancePtr, u32 Data);
u32 XHls_quicksort_Get_arr_1_i(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_1_o(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_1_o_vld(XHls_quicksort *InstancePtr);
void XHls_quicksort_Set_arr_2_i(XHls_quicksort *InstancePtr, u32 Data);
u32 XHls_quicksort_Get_arr_2_i(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_2_o(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_2_o_vld(XHls_quicksort *InstancePtr);
void XHls_quicksort_Set_arr_3_i(XHls_quicksort *InstancePtr, u32 Data);
u32 XHls_quicksort_Get_arr_3_i(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_3_o(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_3_o_vld(XHls_quicksort *InstancePtr);
void XHls_quicksort_Set_arr_4_i(XHls_quicksort *InstancePtr, u32 Data);
u32 XHls_quicksort_Get_arr_4_i(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_4_o(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_4_o_vld(XHls_quicksort *InstancePtr);
void XHls_quicksort_Set_arr_5_i(XHls_quicksort *InstancePtr, u32 Data);
u32 XHls_quicksort_Get_arr_5_i(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_5_o(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_5_o_vld(XHls_quicksort *InstancePtr);
void XHls_quicksort_Set_arr_6_i(XHls_quicksort *InstancePtr, u32 Data);
u32 XHls_quicksort_Get_arr_6_i(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_6_o(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_6_o_vld(XHls_quicksort *InstancePtr);
void XHls_quicksort_Set_arr_7_i(XHls_quicksort *InstancePtr, u32 Data);
u32 XHls_quicksort_Get_arr_7_i(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_7_o(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_7_o_vld(XHls_quicksort *InstancePtr);
void XHls_quicksort_Set_arr_8_i(XHls_quicksort *InstancePtr, u32 Data);
u32 XHls_quicksort_Get_arr_8_i(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_8_o(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_Get_arr_8_o_vld(XHls_quicksort *InstancePtr);

void XHls_quicksort_InterruptGlobalEnable(XHls_quicksort *InstancePtr);
void XHls_quicksort_InterruptGlobalDisable(XHls_quicksort *InstancePtr);
void XHls_quicksort_InterruptEnable(XHls_quicksort *InstancePtr, u32 Mask);
void XHls_quicksort_InterruptDisable(XHls_quicksort *InstancePtr, u32 Mask);
void XHls_quicksort_InterruptClear(XHls_quicksort *InstancePtr, u32 Mask);
u32 XHls_quicksort_InterruptGetEnabled(XHls_quicksort *InstancePtr);
u32 XHls_quicksort_InterruptGetStatus(XHls_quicksort *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
