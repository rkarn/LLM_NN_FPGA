// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xiris_decision_tree_inference.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XIris_decision_tree_inference_CfgInitialize(XIris_decision_tree_inference *InstancePtr, XIris_decision_tree_inference_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XIris_decision_tree_inference_Start(XIris_decision_tree_inference *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIris_decision_tree_inference_ReadReg(InstancePtr->Control_BaseAddress, XIRIS_DECISION_TREE_INFERENCE_CONTROL_ADDR_AP_CTRL) & 0x80;
    XIris_decision_tree_inference_WriteReg(InstancePtr->Control_BaseAddress, XIRIS_DECISION_TREE_INFERENCE_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XIris_decision_tree_inference_IsDone(XIris_decision_tree_inference *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIris_decision_tree_inference_ReadReg(InstancePtr->Control_BaseAddress, XIRIS_DECISION_TREE_INFERENCE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XIris_decision_tree_inference_IsIdle(XIris_decision_tree_inference *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIris_decision_tree_inference_ReadReg(InstancePtr->Control_BaseAddress, XIRIS_DECISION_TREE_INFERENCE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XIris_decision_tree_inference_IsReady(XIris_decision_tree_inference *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIris_decision_tree_inference_ReadReg(InstancePtr->Control_BaseAddress, XIRIS_DECISION_TREE_INFERENCE_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XIris_decision_tree_inference_EnableAutoRestart(XIris_decision_tree_inference *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIris_decision_tree_inference_WriteReg(InstancePtr->Control_BaseAddress, XIRIS_DECISION_TREE_INFERENCE_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XIris_decision_tree_inference_DisableAutoRestart(XIris_decision_tree_inference *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIris_decision_tree_inference_WriteReg(InstancePtr->Control_BaseAddress, XIRIS_DECISION_TREE_INFERENCE_CONTROL_ADDR_AP_CTRL, 0);
}

void XIris_decision_tree_inference_InterruptGlobalEnable(XIris_decision_tree_inference *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIris_decision_tree_inference_WriteReg(InstancePtr->Control_BaseAddress, XIRIS_DECISION_TREE_INFERENCE_CONTROL_ADDR_GIE, 1);
}

void XIris_decision_tree_inference_InterruptGlobalDisable(XIris_decision_tree_inference *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIris_decision_tree_inference_WriteReg(InstancePtr->Control_BaseAddress, XIRIS_DECISION_TREE_INFERENCE_CONTROL_ADDR_GIE, 0);
}

void XIris_decision_tree_inference_InterruptEnable(XIris_decision_tree_inference *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XIris_decision_tree_inference_ReadReg(InstancePtr->Control_BaseAddress, XIRIS_DECISION_TREE_INFERENCE_CONTROL_ADDR_IER);
    XIris_decision_tree_inference_WriteReg(InstancePtr->Control_BaseAddress, XIRIS_DECISION_TREE_INFERENCE_CONTROL_ADDR_IER, Register | Mask);
}

void XIris_decision_tree_inference_InterruptDisable(XIris_decision_tree_inference *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XIris_decision_tree_inference_ReadReg(InstancePtr->Control_BaseAddress, XIRIS_DECISION_TREE_INFERENCE_CONTROL_ADDR_IER);
    XIris_decision_tree_inference_WriteReg(InstancePtr->Control_BaseAddress, XIRIS_DECISION_TREE_INFERENCE_CONTROL_ADDR_IER, Register & (~Mask));
}

void XIris_decision_tree_inference_InterruptClear(XIris_decision_tree_inference *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIris_decision_tree_inference_WriteReg(InstancePtr->Control_BaseAddress, XIRIS_DECISION_TREE_INFERENCE_CONTROL_ADDR_ISR, Mask);
}

u32 XIris_decision_tree_inference_InterruptGetEnabled(XIris_decision_tree_inference *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XIris_decision_tree_inference_ReadReg(InstancePtr->Control_BaseAddress, XIRIS_DECISION_TREE_INFERENCE_CONTROL_ADDR_IER);
}

u32 XIris_decision_tree_inference_InterruptGetStatus(XIris_decision_tree_inference *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XIris_decision_tree_inference_ReadReg(InstancePtr->Control_BaseAddress, XIRIS_DECISION_TREE_INFERENCE_CONTROL_ADDR_ISR);
}

